Tested on ecs-pa-coding servers
Compile and run using the run script provided or compile with "gcc -g main.c -std=gnu89"
Input file must be in the same directory as the compiled program.

