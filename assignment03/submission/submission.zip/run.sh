gcc -fdiagnostics-color=always -g main.c -std=gnu89 -o main.o
./main.o
rm main.o
